# Beginners Guide to Anarchy in the Workplace

first of all if you dont know if you’re not an anarchist, idk what to say to you, go do a buzzfeez quiz or smth. but you’re still welcome to read and have fun :)

now that you know you’re an anarchist, you need to figure out one essential thing. your skills and sector where you wanna work in. I aint helping with that so you’re on your own but whatever domain you pick, you should have a unique combination of some skills there.

“dont just be another cog in the system, be a square peg in round holes.”

~Gandhi probably 

you have interdisciplinary, eg. a marketing+analytics person, a developer who can also do finances, an AI researcher who can actually talk to women, anything. 

this will ensure that your employer cannot fire you because of your unique skillset. with this set, you can start spreading your influence. 

now as an anarchist, you want chaos, not order, so you dont have to care about being nice to your coworkers (doesn’t mean you gotta be rude but that part is totally upto you) and *as they cant fire you*, you will not be having any major problems with the HR.

next up you have to make to eliminate all the religious people near you, they are wasteful and add complexity to your plans. be sure to be rude to them but still in a professional way so that they never talk to you but also cant say anything bad about you to anyone as technically you never did anything.

next up are the managers, just outsmart them, if you cant do that, are you even good for this job?

make sure to have coworkers who are chill and like you. they are crucial to have by your side. dont become friends with them but let them believe you are friends, this will play in your advantage

now that all of these factors are set in, you can start acting on your plan.

start suggesting meaningful changes in the product, this will show them that you are interested in what they’re building and will make them give you more importance/responsibilities

doing this, slowly but steadily climb up heirarchy untill one day you’re sitting with the ceo and having a sketchy discussion.

now here, you have two choices, let’s go thru both: 

1. you can fake-agree with them because the only real thing you believe in is the perpetration of chaos in the world. this will give you short term gains, and if he turns out to be wrong in the future, you were with them at one point so they will respect the comradeship (LAME)

1. the other option is to go against him and have a dick measuring competition to see who stands higher. if you’re in a position to, you can even rat them out to the board and take over. if you dont have evidence, forge it. this should be your goal, to be in talks with the board and oust the present ruler of the empire called your workplace

now that you have power over the company and what it does, you have to make sure not to forget your anarchist roots. this is important, many people lose the game at this point.

now, due to the CEO being ousted, it will cause troubles with stock holders, loyal employees, etc

BUT

you are the CEO now, you can just fire anyone who questions you. if they threaten legal action, send a local gang to kidnap their kids.

meanwhile, wire some company funds into your personal account, its a little illegal but not a big deal this isnt the most illegal thing you’re gonna do

slowly, the company will only be left with incompetent people who dont want to do anything. this is perfect.

call them all to work one day at an odd time like 12 in the night (for people who work in day) and dont tell as to why, just say its crucial and they will be fired if they do not show up.

now before they show up, make sure to keep the workplace clean, like no litter, no random pages lying around, while you’re at it, remove all the paper there is in the room, remove everything apart from chairs, tables, and their computers.

after they show up, make them sit on their desks and as soon as they’re seated, leave and lock the doors from the outside. dont let them leave

optional: you can make this a hunt situation also by hiding food in random places for when they get hungry but thats for you to decide

now let this go on for atleast 3 days, and keep monitoring with the CCTV cameras if your employees are going insane

by this time, outside communication would have made your stock prices collapse and the shit PR you’re getting wont let you raise any more money.

Awesome!

now shut down power to the workplace for a few hours then open the gates

the permanently damaged, employees will now obviously quit and ruin all the other companies 

your employees would now be permanently damaged. this is your time to give a speech, explain to them how society fake and deserves to get cleansed and that pure chaos everywhere is the only solution to it. make them watch mad max if it helps. 

now that they are in your cult and will listen to anything you tell them. ask them to put on a victim mask because they were victims of a very toxic culture. this will help them get hired at other firms. 

after they get another job, explain them how you infiltrated the old company and ask them to do the same. 

remember the money you wired into your account? buy a ranch and a penthouse, ranch to rest, penthouse to watch shit go down

cheers and goodluck :)